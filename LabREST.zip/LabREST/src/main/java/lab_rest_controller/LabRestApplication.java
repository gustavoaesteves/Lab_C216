package lab_rest_controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabRestApplication.class, args);
	}

}
